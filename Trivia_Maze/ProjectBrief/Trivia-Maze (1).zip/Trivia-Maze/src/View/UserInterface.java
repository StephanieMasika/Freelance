package View;
/**
 * UserInterface represents an interface with menu options.
 */
public interface UserInterface {
    /**
     * showMessage displays message to user.
     */
    void showMessage();

    /**
     * printDetail displays to select an option.
     */
    void printDetail();

    /**
     * playerWon displays when the user has won the game.
     */
    void playerWon();

    /**
     * playerLost display when the user has lost the game.
     */
    void playerLost();

    /**
     * displayTitle displays the title of the game.
     */
    void displayTitle();

    /**
     * about displays the information about the game.
     */
    void about();

    /**
     * fileMenu displays the file menu option.
     */
    void fileMenu();

    /**
     * saveGame saves the current game state.
     */
    void saveGame();

    /**
     * loadGame loads a saved game state.
     */
    void loadGame();

    /**
     * exitGame exists the game.
     */
    void exitGame();

    /**
     * helpMenu displays the help menu options.
     */
    void helpMenu();

    /**
     * instructions displays instructions on how to play the game.
     */
    void instructions();

    /**
     * newGame for a new game to start.
     */
    void newGame();
}


