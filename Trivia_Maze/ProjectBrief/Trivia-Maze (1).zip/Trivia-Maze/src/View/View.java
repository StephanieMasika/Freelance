package View;

import Controller.Player;
import Model.*;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class View extends JFrame implements UserInterface, QuestionInterface, RoomInfoInterface, NavigationInterface {
    private static final String SAVE_FILE_EXTENSION = "sav";
    private static Clip myClip;
    private static boolean myMute = false;
    private final Room myCurrentRoom;
    private int myCurrentQuestionIndex = 0;
    private JTextArea myQuestionTextArea;
    private boolean myNextButtonAdded = false;

    private final JPanel myQuestionPanel;
    private final MazePanel myGamePanel;
    private JPanel greenBoxPanel;
    private Player myCurrentPlayer;
    private int myGameDuration = 0;
    private final JLabel myGameDurationLabel;
    private JRadioButton[] myMultipleChoiceOptions;
    private JRadioButton myTrueOption, myFalseOption;
    private JTextField myShortAnswerField;
    private JButton mySubmitButton;
    private MultipleChoiceQuestion myCurrentMcQuestion;

    private ShortAnswerQuestion myCurrentSaQuestion;
    private JPanel myShortAnswerPanel;
    private List<Question> myQuestions;

    public static void main(String[] args) {
        new View();
    }

    public View() {
        fileMenu();
        setTitle("Trivia Maze Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
        add(contentPanel, BorderLayout.CENTER);
        GameModel gameModel = new GameModel();

        if (gameModel.getMaze().getCurrentRoom() == null) {
            myCurrentRoom = new Room(null, null, null, null);
        } else {
            myCurrentRoom = gameModel.getMaze().getCurrentRoom();
        }

        Player player = new Player("Player1", 0, gameModel.getMaze());

        myGamePanel = new MazePanel(player, gameModel);
        myGamePanel.setBackground(new Color(64, 224, 208));
        myGamePanel.setPreferredSize(new Dimension(350, 500));
        myGamePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        contentPanel.add(myGamePanel);
        myGamePanel.requestFocus();

        myQuestionPanel = new JPanel();
        myQuestionPanel.setPreferredSize(new Dimension(350, 500));
        myQuestionPanel.setLayout(new BoxLayout(myQuestionPanel, BoxLayout.Y_AXIS));
        myQuestionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        myQuestionPanel.setBackground(new Color(255, 153, 51));

        greenBoxPanel = new JPanel();
        greenBoxPanel.setBackground(new Color(255, 204, 153));
        greenBoxPanel.setPreferredSize(new Dimension(350, 300));
        greenBoxPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        myQuestionPanel.add(greenBoxPanel);

        myGameDurationLabel = new JLabel("Game Duration: 0 seconds");
        myGameDurationLabel.setFont(new Font("Arial", Font.BOLD, 16));
        myGameDurationLabel.setForeground(new Color(237, 201, 175));
        myGameDurationLabel.setForeground(new Color(25, 25, 112));
        myGamePanel.add(myGameDurationLabel, BorderLayout.NORTH);

        Timer myGameTimer = new Timer(1000, e -> {
            myGameDuration++;
            myGameDurationLabel.setText("Game Duration: " + myGameDuration + " seconds");
        });
        myGameTimer.start();


        contentPanel.add(myQuestionPanel);

        setLocationRelativeTo(null);
        music();


        questionShow();
        SwingUtilities.invokeLater(this::showMessage);
        displayNavigationOptions(myCurrentRoom);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                System.out.println("Key Pressed: " + e.getKeyCode());
                if(((MazePanel) myGamePanel).handleKeyEvent(e)) {
                    displayNextQuestion(myQuestions);
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });

        setFocusable(true);
        requestFocusInWindow();
    }


    private static void music() {
        String path = "src/Resources/game-music-loop-7-145285.wav";
        try {
            File music = new File(path);
            if (music.exists()) {
                AudioInputStream audioInput = AudioSystem.getAudioInputStream(music);
                if (myClip == null) {
                    myClip = AudioSystem.getClip();
                } else {
                    myClip.close();
                    myClip = AudioSystem.getClip();
                }
                myClip.open(audioInput);
                myClip.start();
                myClip.loop(Clip.LOOP_CONTINUOUSLY);
                myMute = false;
            } else {
                System.out.println("Error: Music file not found.");
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            throw new RuntimeException(e);
        }
    }


    private static void musicMute() {
        if (myClip != null) {
            myClip.stop();
            myMute = true;
        }
    }

    private static void musicUnmute() {
        if (myClip != null) {
            if (myMute) {
                myClip.start();
                myClip.loop(Clip.LOOP_CONTINUOUSLY);
                myMute = false;
            }
        }
    }

    private void resetGameTimer() {
        myGameDuration = 0;
        myGameDurationLabel.setText("Game Duration: " + myGameDuration + " seconds");
    }

    @Override
    public void showMessage() {
        JOptionPane.showMessageDialog(this,
                "Welcome to the Trivia Maze Game!\n\nNavigate through the maze by answering trivia questions.",
                "Trivia Maze Game",
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void printDetail() {
        JOptionPane.showMessageDialog(this,
                "Score: " + myCurrentPlayer.getScore(),
                "Game Details",
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void playerWon() {
        JOptionPane.showMessageDialog(this, "Congratulations! You won the game!",
                "Game Over", JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void playerLost() {
        JOptionPane.showMessageDialog(this, "Sorry, you lost the game!",
                "Game Over", JOptionPane.WARNING_MESSAGE);
    }

    @Override
    public void displayTitle() {
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BorderLayout());

        java.net.URL imageUrl = getClass().getResource("/Resources/LoadingScreen.png");
        assert imageUrl != null;
        ImageIcon imageIcon = new ImageIcon(imageUrl);

        Image image = imageIcon.getImage();
        Image scaledImage = image.getScaledInstance(700, 500, Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(scaledImage);

        JLabel imageLabel = new JLabel(imageIcon);
        titlePanel.add(imageLabel, BorderLayout.CENTER);

        getContentPane().add(titlePanel, BorderLayout.CENTER);
        pack();

        int panelHeight = titlePanel.getHeight();

        Timer timer = new Timer(12, e -> {
            int y = titlePanel.getY() - 1;
            if (y + panelHeight < 0) {
                ((Timer) e.getSource()).stop();
                getContentPane().remove(titlePanel);
                revalidate();
                repaint();
            } else {
                titlePanel.setLocation(titlePanel.getX(), y);
            }
        });

        timer.start();
    }

    @Override
    public void about() {
        JDialog aboutDialog = new JDialog(this, "About", true);
        aboutDialog.setLayout(new BorderLayout());

        JTextArea aboutArea = new JTextArea();
        aboutArea.setEditable(false);
        aboutArea.setLineWrap(true);
        aboutArea.setWrapStyleWord(true);
        aboutArea.setText("""
                Welcome to the Trivia Maze Game!

                This game challenges you to navigate through a maze by answering questions.
                
                Each room in the maze contains a question, and you must answer it correctly to unlock the door and move to the next room.

                Be careful! Incorrect answers can lead to locked doors and dead ends.

                Explore the maze, answer questions, and find your way to the exit!""");

        aboutDialog.add(new JScrollPane(aboutArea), BorderLayout.CENTER);
        aboutDialog.pack();
        aboutDialog.setLocationRelativeTo(this);
        aboutDialog.setVisible(true);
    }

    @Override
    public void fileMenu() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("File");
        menuBar.add(menuFile);

        JMenuItem menuFileNewGame = new JMenuItem("New Game");
        menuFileNewGame.addActionListener(e -> newGame());
        menuFile.add(menuFileNewGame);

        JMenuItem menuFileItemSaveGame = new JMenuItem("Save Game");
        menuFileItemSaveGame.addActionListener(e -> saveGame());
        menuFile.add(menuFileItemSaveGame);

        JMenuItem menuFileItemLoadGame = new JMenuItem("Load Game");
        menuFileItemLoadGame.addActionListener(e -> loadGame());
        menuFile.add(menuFileItemLoadGame);

        JMenuItem menuFileItemExit = new JMenuItem("Exit");
        menuFileItemExit.addActionListener(e -> exitGame());
        menuFile.add(menuFileItemExit);

        JMenuItem menuFileItemMute = new JMenuItem("Mute Music");
        menuFileItemMute.addActionListener(e -> musicMute());
        menuFile.add(menuFileItemMute);

        JMenuItem menuFileItemUnmute = new JMenuItem("Unmute Music");
        menuFileItemUnmute.addActionListener(e -> musicUnmute());
        menuFile.add(menuFileItemUnmute);

        JMenu menuHelp = new JMenu("Help");
        menuBar.add(menuHelp);

        JMenuItem menuHelpItemAbout = new JMenuItem("About");
        menuHelpItemAbout.addActionListener(e -> about());
        menuHelp.add(menuHelpItemAbout);

        JMenuItem menuHelpItemInstructions = new JMenuItem("Instructions");
        menuHelpItemInstructions.addActionListener(e -> instructions());
        menuHelp.add(menuHelpItemInstructions);

        JMenu roomInfo = new JMenu("Info");
        menuBar.add(roomInfo);

        JMenuItem menuRoomInfo = new JMenuItem("Room Info");
        menuRoomInfo.addActionListener(e -> displayRoomInfo(myCurrentRoom));
        roomInfo.add(menuRoomInfo);

//        JMenuItem menuDisplayNavigation = new JMenuItem("Navigation");
//        menuDisplayNavigation.addActionListener(e -> displayNavigationOptions(myCurrentRoom));
//        roomInfo.add(menuDisplayNavigation);

        setJMenuBar(menuBar);
        displayTitle();
        setVisible(true);
    }

    @Override
    public void saveGame() {
        showSaveGameDialog(this);
    }

    private void showSaveGameDialog(JFrame theParent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Game");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.setFileFilter(new FileNameExtensionFilter("Save Files", SAVE_FILE_EXTENSION));

        int result = fileChooser.showSaveDialog(theParent);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            if (!selectedFile.getName().endsWith("." + SAVE_FILE_EXTENSION)) {
                selectedFile = new File(selectedFile.getParentFile(), selectedFile.getName() + "." + SAVE_FILE_EXTENSION);
            }

            int confirmResult = JOptionPane.showConfirmDialog(theParent,
                    "Are you sure you want to save the game?",
                    "Confirm Save", JOptionPane.YES_NO_OPTION);

            if (confirmResult == JOptionPane.YES_OPTION) {
                try (FileWriter writer = new FileWriter(selectedFile)) {
                    // Write game data to the file
                    writer.write("Game data goes here");

                    JOptionPane.showMessageDialog(theParent,
                            "Game saved successfully.",
                            "Save Success",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException e) {
                    // Handle the exception appropriately
                    JOptionPane.showMessageDialog(theParent,
                            "Error saving game: " + e.getMessage(),
                            "Save Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else if (result == JFileChooser.CANCEL_OPTION) {
            // Handle the cancel operation if needed
        }
    }

    @Override
    public void loadGame() {
        showLoadGameDialog(this);
    }

    private void showLoadGameDialog(JFrame theParent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Load Game");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.setFileFilter(new FileNameExtensionFilter("Save Files", SAVE_FILE_EXTENSION));

        int result = fileChooser.showOpenDialog(theParent);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();

            try (FileInputStream fileIn = new FileInputStream(selectedFile);
                 ObjectInputStream in = new ObjectInputStream(fileIn)) {
                GameState loadedGameState = (GameState) in.readObject();
                updateGameState(loadedGameState);

                JOptionPane.showMessageDialog(theParent,
                        "Game loaded successfully.",
                        "Load Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(theParent,
                        "The selected file was not found.",
                        "Load Error",
                        JOptionPane.ERROR_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(theParent,
                        "An error occurred while reading the file: " + e.getMessage(),
                        "Load Error",
                        JOptionPane.ERROR_MESSAGE);
            } catch (ClassNotFoundException e) {
                JOptionPane.showMessageDialog(theParent,
                        "The game data in the file is not compatible with the current version of the game.",
                        "Load Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } else if (result == JFileChooser.CANCEL_OPTION) {
            // Handle the cancel operation if needed
        }
    }

    private void updateGameState(GameState theLoadedGameState) {
        // Update the game state with the loaded game data
        firePropertyChange("gameState", null, theLoadedGameState);
    }

    @Override
    public void exitGame() {
        int exit = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to exit the game?", "Exit Game", JOptionPane.YES_NO_OPTION);
        if (exit == JOptionPane.YES_OPTION) {
            musicStop();
            System.exit(0);
        }
    }

    @Override
    public void helpMenu() {
        JDialog help = new JDialog(this, "Help Menu", true);
        help.setLayout(new GridLayout(2, 1, 10, 10));
        help.setPreferredSize(new Dimension(300, 100));

        JButton aboutButton = new JButton("About");
        aboutButton.addActionListener(e -> about());

        JButton instructionsButton = new JButton("Instructions");
        instructionsButton.addActionListener(e -> instructions());

        help.add(aboutButton);
        help.add(instructionsButton);

        help.pack();
        help.setLocationRelativeTo(this);
        help.setVisible(true);
    }

    @Override
    public void instructions() {
        JDialog instructions = new JDialog(this, "Game Instructions", true);
        instructions.setLayout(new BorderLayout());

        JTextArea instructionsArea = new JTextArea();
        instructionsArea.setEditable(false);
        instructionsArea.setLineWrap(true);
        instructionsArea.setWrapStyleWord(true);
        instructionsArea.setText("""
                Game Play Instructions:

                1. Enter the maze and navigate through each room.
                2. To pass through each door, answer one of the three possible questions:
                   - Multiple Choice
                   - True/False
                   - Short Answer (one or two words/numbers)
                3. If you answer correctly, the door will be unlocked.
                4. If you answer incorrectly, the door will be permanently locked, and the game ends.
                5. Your goal is to reach the exit of the maze.""");

        instructions.add(new JScrollPane(instructionsArea), BorderLayout.CENTER);
        instructions.pack();
        instructions.setLocationRelativeTo(this);
        instructions.setVisible(true);
    }

    @Override
    public void newGame() {
        int option = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to start a new game?", "New Game Confirmation",
                JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            resetGameState();
            resetGameTimer();
            musicStop();
            music();
            questionShow();
        }
    }

    //    private void resetGameState() {
//        myQuestionPanel.removeAll();
//        myQuestionTextArea = null;
//        myNextButtonAdded = false;
//        myCurrentQuestionIndex = -1;
//
//        musicStop();
//        music();
//    }
    private void resetGameState() {
        Component[] components = myQuestionPanel.getComponents();
        for (Component component : components) {
            if (!(component instanceof JPanel && component == greenBoxPanel)) {
                myQuestionPanel.remove(component);
            }
        }


        myQuestionTextArea = null;
        myNextButtonAdded = false;
        myCurrentQuestionIndex = -1;

        myCurrentPlayer = new Player("Player1", 0, new GameModel().getMaze());
        myGamePanel.setPlayer(myCurrentPlayer);
        myGamePanel.resetDoorsState();
        myGamePanel.repaint();

        musicStop();
        music();

        myQuestionPanel.revalidate();
        myQuestionPanel.repaint();
    }


    private static void musicStop() {
        if (myClip != null) {
            myClip.stop();
            myClip.close();
            myClip = null;
            myMute = true;
        }
    }

    private void questionShow() {
        SQLQuestionDataBase.initializeDatabase();
        List<String> questionTypes = Arrays.asList("Multiple-Choice", "True/False", "Short Answer");
        List<Question> questions = QuestionFactory.getQuestionsFromDatabase(questionTypes);
        myQuestions = questions;

        if (!questions.isEmpty()) {
            myCurrentQuestionIndex = 0;
            displayQuestion(questions.get(myCurrentQuestionIndex));
        } else {
            JOptionPane.showMessageDialog(this, "No questions found.");
        }

        if (!myNextButtonAdded) {
            //JButton nextButton = new JButton("Next");
            //nextButton.addActionListener(e -> displayNextQuestion(questions));
           // myQuestionPanel.add(nextButton);
            myQuestionPanel.setBackground(new Color(255, 153, 51));
            myNextButtonAdded = true;
        }

        revalidate();
        repaint();
    }

    @Override
    public void displayQuestion(final Question theQuestion) {
        if (myQuestionTextArea == null) {
            myQuestionTextArea = new JTextArea();
            myQuestionTextArea.setEditable(false);
            myQuestionTextArea.setLineWrap(true);
            myQuestionTextArea.setWrapStyleWord(true);
            myQuestionTextArea.setPreferredSize(new Dimension(400, 100));
            myQuestionTextArea.setBackground(new Color(255, 153, 51));
            myQuestionPanel.add(myQuestionTextArea);
        }

        clearInputComponents();

        myQuestionTextArea.setText("Question:\n" + theQuestion.getQuestionText());

        if (theQuestion instanceof MultipleChoiceQuestion mcQuestion) {
            displayMultipleChoiceOptions(mcQuestion);
        } else if (theQuestion instanceof TrueFalseQuestion tfQuestion) {
            displayTrueFalseOptions(tfQuestion);
        } else if (theQuestion instanceof ShortAnswerQuestion shortAnswerQuestion) {
            displayShortAnswerInput(shortAnswerQuestion);
        }

        myGamePanel.requestFocus();

        revalidate();
        repaint();
    }

    private void clearInputComponents() {
        if (myMultipleChoiceOptions != null) {
            for (JRadioButton option : myMultipleChoiceOptions) {
                myQuestionPanel.remove(option);
            }
        }
        if (myTrueOption != null) {
            myQuestionPanel.remove(myTrueOption);
            myQuestionPanel.remove(myFalseOption);
        }
        if (myShortAnswerField != null) {
            myQuestionPanel.remove(myShortAnswerField);
        }
    }

    private void displayMultipleChoiceOptions(MultipleChoiceQuestion theMcQuestion) {
        myCurrentMcQuestion = theMcQuestion;

        String[] choices = theMcQuestion.getChoices();
        if (choices != null && choices.length > 0) {
            ButtonGroup optionsGroup = new ButtonGroup();
            myMultipleChoiceOptions = new JRadioButton[choices.length];
            for (int i = 0; i < choices.length; i++) {
                myMultipleChoiceOptions[i] = new JRadioButton(choices[i]);
                optionsGroup.add(myMultipleChoiceOptions[i]);
                myQuestionPanel.add(myMultipleChoiceOptions[i]);

                int finalI = i;
                myMultipleChoiceOptions[i].addActionListener(e -> {
                    checkMultipleChoiceAnswer(myMultipleChoiceOptions[finalI].getText());
                    disableMultipleChoiceOptions();
                });
            }
        }
    }


    private void disableMultipleChoiceOptions() {
        if (myMultipleChoiceOptions != null) {
            for (JRadioButton option : myMultipleChoiceOptions) {
                option.setEnabled(false);
            }
        }
    }

    private void checkMultipleChoiceAnswer(String theSelectedAnswer) {
        if (myCurrentMcQuestion == null) {
            return;
        }

        String correctAnswer = myCurrentMcQuestion.getAnswerText();

        if (theSelectedAnswer.equalsIgnoreCase(correctAnswer)) {
            JOptionPane.showMessageDialog(this, "Correct!");
            displayNavigationOptions(myCurrentRoom);
            //myGamePanel.openDoor();
            repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect. The correct answer is " + correctAnswer + ".");
        }
    }

    private void displayTrueFalseOptions(TrueFalseQuestion theTfQuestion) {
        myTrueOption = new JRadioButton("True");
        myFalseOption = new JRadioButton("False");
        ButtonGroup optionsGroup = new ButtonGroup();
        optionsGroup.add(myTrueOption);
        optionsGroup.add(myFalseOption);
        myQuestionPanel.add(myTrueOption);
        myQuestionPanel.add(myFalseOption);

        myTrueOption.addActionListener(e -> {
            checkAnswer(theTfQuestion, true);
            disableTrueFalseOptions();
        });

        myFalseOption.addActionListener(e -> {
            checkAnswer(theTfQuestion, false);
            disableTrueFalseOptions();
        });
    }


    private void disableTrueFalseOptions() {
        if (myTrueOption != null && myFalseOption != null) {
            myTrueOption.setEnabled(false);
            myFalseOption.setEnabled(false);
        }
    }

    private void checkAnswer(TrueFalseQuestion theTfQuestion, boolean theSelectedAnswer) {
        String correctAnswer = theTfQuestion.getAnswerText();
        boolean isCorrect = (theSelectedAnswer && correctAnswer.equalsIgnoreCase("true")) ||
                (!theSelectedAnswer && correctAnswer.equalsIgnoreCase("false"));

        if (isCorrect) {
            JOptionPane.showMessageDialog(this, "Correct!");
            displayNavigationOptions(myCurrentRoom);
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect. The correct answer is " + correctAnswer + ".");
        }
    }

    private void displayShortAnswerInput(ShortAnswerQuestion theShortAnswerQuestion) {
        myCurrentSaQuestion = theShortAnswerQuestion;
        clearInputSA();

        myShortAnswerField = new JTextField(20);
        JLabel wordLimitLabel = new JLabel("Answer is limited to 2 words");
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            checkShortAnswer();
            myShortAnswerField.setEnabled(false);
            submitButton.setEnabled(false);
        });

        myShortAnswerPanel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        topPanel.add(wordLimitLabel);
        topPanel.add(submitButton);
        myShortAnswerPanel.add(topPanel, BorderLayout.NORTH);

        myShortAnswerPanel.add(myShortAnswerField, BorderLayout.CENTER);

        myQuestionPanel.add(myShortAnswerPanel, BorderLayout.SOUTH);

        myShortAnswerPanel.setVisible(true);

        revalidate();
        repaint();
    }

    private void clearInputSA() {
        if (myShortAnswerPanel != null) {
            myQuestionPanel.remove(myShortAnswerPanel);
            myShortAnswerPanel.removeAll();
            myShortAnswerPanel = null;
            myShortAnswerField = null;
        }
        myQuestionPanel.revalidate();
        myQuestionPanel.repaint();
    }




    private void checkShortAnswer() {
        if (myCurrentSaQuestion == null) {
            return;
        }

        String userAnswer = myShortAnswerField.getText().trim();
        String correctAnswer = myCurrentSaQuestion.getAnswerText();

        if (userAnswer.equalsIgnoreCase(correctAnswer)) {
            displayFeedbackAndNextQuestion("Correct!");
            displayNavigationOptions(myCurrentRoom);
        } else {
            displayFeedbackAndNextQuestion("Incorrect. The correct answer is " + correctAnswer + ".");
        }
    }

    private void displayFeedbackAndNextQuestion(String theFeedbackMessage) {
        JOptionPane optionPane = new JOptionPane(theFeedbackMessage, JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = optionPane.createDialog(this, "Answer Feedback");
        dialog.setAlwaysOnTop(true);
        dialog.setVisible(true);

        clearInput();
    }


    private void clearInput() {
        if (myShortAnswerPanel != null) {
            myQuestionPanel.remove(myShortAnswerPanel);
            myShortAnswerPanel.removeAll();
            myShortAnswerPanel = null;
            revalidate();
            repaint();
        }
    }

    private void displayNextQuestion(List<Question> theQuestions) {
        if (theQuestions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No questions found.");
            return;
        }
        int randomIndex = (int) (Math.random() * theQuestions.size());

        displayQuestion(theQuestions.get(randomIndex));
    }
    @Override
    public void displayRoomInfo(final Room theRoom) {
        if (theRoom != null) {
            JDialog roomInfo = new JDialog(this, "Room Information", true);
            roomInfo.setLayout(new BorderLayout());

            JTextArea roomInfoArea = new JTextArea();
            roomInfoArea.setEditable(false);
            roomInfoArea.setLineWrap(true);
            roomInfoArea.setWrapStyleWord(true);

            String roomInfoText = theRoom.toString();

            roomInfoArea.setText(roomInfoText);

            roomInfo.add(new JScrollPane(roomInfoArea), BorderLayout.CENTER);
            roomInfo.pack();
            roomInfo.setLocationRelativeTo(this);
            roomInfo.setVisible(true);
        } else {
            System.out.println("Room object is null. Cannot display room information.");
        }
    }

    @Override
    public void displayNavigationOptions(final Room theRoom) {
        if (theRoom != null) {
            greenBoxPanel.removeAll();

            JLabel directionLabel = new JLabel("<html>Choose a direction to move<br>before answering a question:</html>");
            directionLabel.setFont(new Font("Arial", Font.BOLD, 14));
            directionLabel.setForeground(Color.BLACK);

            directionLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
            greenBoxPanel.add(directionLabel);

            JButton northButton = new JButton("Go North");
            northButton.addActionListener(e -> {
                // do smthing
                myGamePanel.openDoor(Direction.NORTH);
            });

            JButton southButton = new JButton("Go South");
            southButton.addActionListener(e -> {
                // do smthing
                myGamePanel.openDoor(Direction.SOUTH);
            });

            JButton eastButton = new JButton("Go East");
            eastButton.addActionListener(e -> {

                // do smthing
                myGamePanel.openDoor(Direction.EAST);
            });

            JButton westButton = new JButton("Go West");
            westButton.addActionListener(e -> {
                // do smthing
                myGamePanel.openDoor(Direction.WEST);
            });

            greenBoxPanel.add(northButton);
            greenBoxPanel.add(southButton);
            greenBoxPanel.add(eastButton);
            greenBoxPanel.add(westButton);

            greenBoxPanel.revalidate();
            greenBoxPanel.repaint();
        } else {
            System.out.println("Room object is null. Cannot display navigation options.");
        }
    }
    // Property Change Listeners
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        addPropertyChangeListener("gameState", listener);
    }
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        removePropertyChangeListener("gameState", listener);
    }
}


