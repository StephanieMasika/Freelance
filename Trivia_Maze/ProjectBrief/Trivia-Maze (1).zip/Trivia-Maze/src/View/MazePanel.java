package View;

import Model.*;
import Controller.Player;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MazePanel extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(MazePanel.class.getName());

    private Player myPlayer;
    private final GameModel myGameModel;

    private final Maze myMaze;
    private BufferedImage myPlayerImage;
    private BufferedImage myEndImage;

    public MazePanel(Player thePlayer, GameModel theGameModel) {

        myPlayer = thePlayer;
        myGameModel = theGameModel;
        myMaze = myGameModel.getMaze();
        loadPlayerImage();
        loadExitImage();

        this.setFocusable(true);
        this.requestFocusInWindow();
    }

    //    public void openDoor() {
//        System.out.println("Opening door to the right");
//        Room currentRoom = myGameModel.getPlayerLocation();
//        Direction direction = Direction.EAST;
//        Door door = currentRoom.getDoor(direction);
//        if (door != null) {
//            System.out.println("here");
//            door.doorOpen();
//            myGameModel.updateDoorState(currentRoom, direction, door.isLock());
//            repaint();
//        }
//    }

    public void openDoor(Direction theDirection) {
        Room currentRoom = myGameModel.getPlayerLocation();
        int currentRow = myPlayer.getCurrentRow();
        int currentCol = myPlayer.getCurrentCol();

        int newRow = currentRow;
        int newCol = currentCol;

        switch (theDirection) {
            case NORTH:
                newRow = currentRow - 1;
                break;
            case SOUTH:
                newRow = currentRow + 1;
                break;
            case EAST:
                newCol = currentCol + 1;
                break;
            case WEST:
                newCol = currentCol - 1;
                break;
        }

        if (newRow >= 0 && newRow < myMaze.myMaze.length && newCol >= 0 && newCol < myMaze.myMaze[0].length) {
            Room otherRoom = myMaze.myMaze[newRow][newCol];
            Door door = currentRoom.getDoor(theDirection);

            Direction oppositeDirection;
            switch (theDirection) {
                case NORTH:
                    oppositeDirection = Direction.SOUTH;
                    break;
                case SOUTH:
                    oppositeDirection = Direction.NORTH;
                    break;
                case EAST:
                    oppositeDirection = Direction.WEST;
                    break;
                case WEST:
                    oppositeDirection = Direction.EAST;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid direction");
            }

            Door otherDoor = otherRoom.getDoor(oppositeDirection);

            if (door != null) {
                door.doorOpen();
                if (otherDoor != null) {
                    otherDoor.doorOpen();
                }
                myGameModel.updateDoorState(currentRoom, theDirection, door.isLock());
                myGameModel.updateDoorState(otherRoom, oppositeDirection, otherDoor.isLock());

                myGameModel.setPlayerLocation(otherRoom);

                repaint();
            }
        } else {
            System.out.println("Cannot move in the given direction, out of maze bounds.");
        }
    }

    public boolean handleKeyEvent(KeyEvent e) {
        Direction direction = getDirectionFromKeyEvent(e);
        if (direction != null) {
            movePlayer(direction);
            repaint();
            return true;
        }
        return false;
    }

    private Direction getDirectionFromKeyEvent(KeyEvent e) {
        return switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> Direction.NORTH;
            case KeyEvent.VK_DOWN -> Direction.SOUTH;
            case KeyEvent.VK_LEFT -> Direction.WEST;
            case KeyEvent.VK_RIGHT -> Direction.EAST;
            default -> null;
        };
    }

    private void movePlayer(Direction theDirection) {
        switch (theDirection) {
            case NORTH -> {
                if (myPlayer.getCurrentRow() > 0) {
                    myPlayer.moveNorth();
                }
            }
            case SOUTH -> {
                if (myPlayer.getCurrentRow() < myMaze.getRows() - 1) {
                    myPlayer.moveSouth();
                }
            }
            case WEST -> {
                if (myPlayer.getCurrentCol() > 0) {
                    myPlayer.moveWest();
                }
            }
            case EAST -> {
                if (myPlayer.getCurrentCol() < myMaze.getCols() - 1) {
                    myPlayer.moveEast();
                }
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D G2D = (Graphics2D) g;

        if (myMaze == null || myMaze.myMaze == null || myPlayerImage == null || myEndImage == null) {
            return;
        }

        int rows = myMaze.getRows();
        int cols = myMaze.getCols();
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        int cellSize = Math.min(panelWidth / cols, panelHeight / rows);

        int mazeWidth = cols * cellSize;
        int mazeHeight = rows * cellSize;

        double scalingFactor = 0.8;
        double iconScalingFactor = 0.9;

        int scaledMazeWidth = (int) (mazeWidth * scalingFactor);
        int scaledMazeHeight = (int) (mazeHeight * scalingFactor);

        int offsetX = (panelWidth - scaledMazeWidth) / 2;
        int offsetY = (panelHeight - scaledMazeHeight) / 2;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                Room room = myMaze.myMaze[i][j];

                if (room != null) {
                    int x = offsetX + (int) (j * cellSize * scalingFactor);
                    int y = offsetY + (int) (i * cellSize * scalingFactor);
                    int scaledCellSize = (int) (cellSize * scalingFactor);

                    if (room.getStart()) {
                        int scaledBoxSize = (int) (scaledCellSize * 0.8);
                        G2D.setColor(Color.BLUE);
                        G2D.fillRect(x + (scaledCellSize - scaledBoxSize) / 2, y + (scaledCellSize - scaledBoxSize) / 2, scaledBoxSize, scaledBoxSize);
                    } else if (room.getExit()) {
                        int scaledIconSize = (int) (cellSize * scalingFactor * iconScalingFactor);
                        G2D.drawImage(myEndImage, x, y, scaledIconSize, scaledIconSize, null);
                    }

                    G2D.setColor(Color.BLACK);

                    for (Door door : room.getDoors()) {
                        if (door.isLock()) {
                            drawLockedDoor(G2D, x, y, scaledCellSize, door.getDirection());
                        } else if (door.isClosed()) {
                            drawClosedDoor(G2D, x, y, scaledCellSize, door.getDirection());
                        } else {
                            drawUnlockedDoor(G2D, x, y, scaledCellSize, door.getDirection());
                        }
                    }
                }
            }
        }

        if (myPlayer != null) {
            int playerX = offsetX + (int) (myPlayer.getCurrentCol() * cellSize * scalingFactor);
            int playerY = offsetY + (int) (myPlayer.getCurrentRow() * cellSize * scalingFactor);
            int scaledIconSize = (int) (cellSize * scalingFactor * iconScalingFactor);
            g.drawImage(myPlayerImage, playerX, playerY, scaledIconSize, scaledIconSize, null);
        }
    }

    private void drawClosedDoor(Graphics2D theG, int theX, int theY, int theCellSize, Direction theDirection) {
        theG.setColor(Color.WHITE);

        switch (theDirection) {
            case NORTH -> theG.drawLine(theX, theY, theX + theCellSize, theY);
            case SOUTH -> theG.drawLine(theX, theY + theCellSize, theX + theCellSize, theY + theCellSize);
            case EAST -> theG.drawLine(theX + theCellSize, theY, theX + theCellSize, theY + theCellSize);
            case WEST -> theG.drawLine(theX, theY, theX, theY + theCellSize);
        }
    }

    private void drawLockedDoor(Graphics2D theG, int theX, int theY, int theCellSize, Direction theDirection) {
        theG.setColor(new Color(255, 127, 80));
        switch (theDirection) {
            case NORTH -> theG.drawLine(theX, theY, theX + theCellSize, theY);
            case SOUTH -> theG.drawLine(theX, theY + theCellSize, theX + theCellSize, theY + theCellSize);
            case EAST -> theG.drawLine(theX + theCellSize, theY, theX + theCellSize, theY + theCellSize);
            case WEST -> theG.drawLine(theX, theY, theX, theY + theCellSize);
        }
    }

    private void drawUnlockedDoor(Graphics2D theG, int theX, int theY, int theCellSize, Direction theDirection) {
        theG.setColor(new Color(255, 153, 204));

        switch (theDirection) {
            case NORTH -> theG.drawLine(theX, theY, theX + theCellSize, theY);
            case SOUTH -> theG.drawLine(theX, theY + theCellSize, theX + theCellSize, theY + theCellSize);
            case EAST -> theG.drawLine(theX + theCellSize, theY, theX + theCellSize, theY + theCellSize);
            case WEST -> theG.drawLine(theX, theY, theX, theY + theCellSize);
        }
    }

    private void loadPlayerImage() {
        try {
            myPlayerImage = ImageIO.read(new File("src/Resources/player.png"));
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error loading player image", e);
        }
    }

    private void loadExitImage() {
        try {
            myEndImage = ImageIO.read(new File("src/Resources/Exit.png"));
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error loading exit image", e);
        }
    }

    private void displayQuestion(Room theCurrentRoom, Direction theDirection) {
        Door door = theCurrentRoom.getDoor(theDirection);
        if (door != null && door.isLock()) {
            Question question = (Question) door.getQuestions();
            String userAnswer = JOptionPane.showInputDialog(this, question.getQuestionText());
            handleUserAnswer(userAnswer, theCurrentRoom, theDirection);
        }
    }

    private void handleUserAnswer(String theUserAnswer, Room theCurrentRoom, Direction theDirection) {
        Door door = theCurrentRoom.getDoor(theDirection);
        if (door != null) {
            Question question = (Question) door.getQuestions();
            String correctAnswer = question.getAnswerText();

            if (theUserAnswer.equalsIgnoreCase(correctAnswer)) {
                door.doorOpen();
            } else {
                door.permanentlyLocked();
            }

            myGameModel.updateDoorState(theCurrentRoom, theDirection, door.isLock());

        }
    }

    public void setPlayer(Player thePlayer) {
        myPlayer = thePlayer;
    }
    public void resetDoorsState() {
        for (int i = 0; i < myMaze.getRows(); i++) {
            for (int j = 0; j < myMaze.getCols(); j++) {
                Room room = myMaze.myMaze[i][j];
                if (room != null) {
                    for (Door door : room.getDoors()) {
                        door.reset();
                    }
                }
            }
        }
        repaint();
    }

}



