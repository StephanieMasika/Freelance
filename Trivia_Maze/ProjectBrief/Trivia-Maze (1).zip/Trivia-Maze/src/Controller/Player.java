package Controller;

import Model.Direction;
import Model.Maze;

import java.io.Serializable;

public class Player implements Serializable {
    //private static final long mySerial = 1L;
    private final String myName;
    private int myScore;
    private int currentRow;
    private int currentCol;
    private final Maze myMaze;

    // Change this to public
    public Player (final String theName, final int theScore, final Maze theMaze){
        myName = theName;
        myScore = theScore;
        myMaze = theMaze;
        currentRow = 0; //starting at top left corner
        currentCol = 0; //starting at top left corner
    }

    public String getName(){
        return myName;
    }

    public int getScore(){
        return myScore;
    }

    public void setScore(final int theScore){
        if (theScore < 0) {
            throw new IllegalArgumentException("Score cannot be negative");
        }
        myScore = theScore;
    }

    public void moveNorth() {
        move(Direction.NORTH);
    }

    public void moveSouth() {
        move(Direction.SOUTH);
    }

    public void moveEast() {
        move(Direction.EAST);
    }

    public void moveWest() {
        move(Direction.WEST);
    }

    private void move(final Direction theDirection) {
        switch (theDirection) {
            case NORTH:
                currentRow--;
                break;
            case SOUTH:
                currentRow++;
                break;
            case EAST:
                currentCol++;
                break;
            case WEST:
                currentCol--;
                break;
        }
    }


    public int getCurrentRow() {
        return currentRow;
    }

    public int getCurrentCol() {
        return currentCol;
    }

    @Override
    public String toString() {
        return "Player: " + myName + ", Score: " + myScore;
    }
}
