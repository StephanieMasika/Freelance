package Controller;

import Model.*;
import View.NavigationInterface;
import View.QuestionInterface;
import View.RoomInfoInterface;
import View.UserInterface;

import java.util.Random;

public class TriviaController {
    private Maze myMaze;
    private final UserInterface myUser;
    private final QuestionInterface myQuestion;
    private final RoomInfoInterface myRoomInfo;
    private final NavigationInterface myNavigation;
    private Room myCurrentRoom;
    private final Player myPlayer;
    public TriviaController(final UserInterface theUser, final QuestionInterface theQuestion,
                            final RoomInfoInterface theRoomInfo, final NavigationInterface theNavigation,
                            final Player thePlayer, final Maze theMaze) {
        myUser = theUser;
        myQuestion = theQuestion;
        myRoomInfo = theRoomInfo;
        myNavigation = theNavigation;
        myPlayer = thePlayer;
        myMaze = theMaze;
    }
    public static void main(final String[] args) {
        Maze maze = new Maze();
        printMazeState(maze);
        while (!maze.endOfMazeCheck()) {
            Direction randomDirection = getRandomDirection();
            maze.movePlayer(randomDirection);
            printMazeState(maze);
        }

        System.out.println("you reached the end");
    }
    private static Direction getRandomDirection() {
        Random random = new Random();
        return Direction.values()[random.nextInt(Direction.values().length)];
    }
    private static void printMazeState(final Maze theMaze) {
        System.out.println(theMaze.toString());
    }
}
