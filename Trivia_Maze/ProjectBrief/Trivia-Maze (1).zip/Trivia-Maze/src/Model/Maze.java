package Model;

import java.io.Serializable;
import java.util.*;

public class Maze implements Serializable {
    private int myRows;
    private int myCols;
    private int myPlayerRow;
    private int myPlayerCol;
    public final Room[][] myMaze;
    private final int myMazeSize = 3;
    private final Random myRandom;

    public Maze() {
        myRows = myMazeSize;
        myCols = myMazeSize;
        myMaze = new Room[myMazeSize][myMazeSize];
        myRandom = new Random();
        myPlayerCol = 0;
        myPlayerRow = 0;
        initializeMaze();
        generateMaze();
    }

    public int getRows() {
        return myRows;
    }

    public int getCols() {
        return myCols;
    }

    /**
     * Generates a maze using the recursive backtracking algorithm.
     */
    public void generateMaze() {
        // Initialize maze with walls
        initializeMaze();

        // Start generating maze from a random room
        final int startRow = myRandom.nextInt(myMazeSize);
        final int startCol = myRandom.nextInt(myMazeSize);

        // Create a stack to keep track of visited rooms
        final Stack<Room> stack = new Stack<>();
        Room currentRoom = myMaze[startRow][startCol];
        currentRoom.setVisited(true);
        stack.push(currentRoom);

        while (!stack.isEmpty()) {
            // Get current room
            currentRoom = stack.peek();
            final int rows = currentRoom.getRow();
            final int cols = currentRoom.getCol();

            // Get neighboring rooms
            final List<Room> neighbors = getUnvisitedNeighbors(rows, cols);

            if (!neighbors.isEmpty()) {
                // Choose a random neighbor
                final Room randomNeighbor = neighbors.get(myRandom.nextInt(neighbors.size()));

                // Remove wall between current room and chosen neighbor
                removeWall(currentRoom, randomNeighbor);

                // Mark the neighbor as visited and push it to the stack
                randomNeighbor.setVisited(true);
                stack.push(randomNeighbor);
            } else {
                // If there are no unvisited neighbors, backtrack
                stack.pop();
            }
        }
    }

    /**
     * Initializes the maze grid by creating a new Room object for each cell in the grid,
     * with Door objects for each direction (north, south, east, west).
     * Each Room object is initialized with the same set of Door objects.
     * The Door objects are initially set to have no lock and be closed.
     * <p>
     * This method creates Door objects for each direction (north, south, east, west)
     * with the initial state of unlocked and closed. Then, it iterates over each cell
     * in the maze grid and assigns a new Room object to it, passing the same set of
     * Door objects for each direction to the Room constructor.
     *
     * @see Room
     * @see Door
     */
    private void initializeMaze() {
        for (int rows = 0; rows < myMazeSize; rows++) {
            for (int cols = 0; cols < myMazeSize; cols++) {

                final Door northDoor = new Door(false, true, Direction.NORTH);
                final Door southDoor = new Door(false, true, Direction.SOUTH);
                final Door eastDoor = new Door(false, true, Direction.EAST);
                final Door westDoor = new Door(false, true, Direction.WEST);

                Room room = new Room(northDoor, southDoor, eastDoor, westDoor);

                if (rows == 0 && cols == 0) {
                    room.setStart(true);
                } else if (rows == myMazeSize - 1 && cols == myMazeSize - 1) {
                    room.setExit(true);
                }

                myMaze[rows][cols] = room;
            }
        }
    }

    /**
     * Gets unvisited neighboring rooms of a given room.
     *
     * @param theRow The x-coordinate of the room.
     * @param theCol The y-coordinate of the room.
     * @return A list of unvisited neighboring rooms.
     */
    private List<Room> getUnvisitedNeighbors(final int theRow, final int theCol) {
        final List<Room> neighbors = new ArrayList<>();
        if (isValidRoom(theRow - 1, theCol) && !myMaze[theRow - 1][theCol].getVisited()) {
            neighbors.add(myMaze[theRow - 1][theCol]);
        }
        if (isValidRoom(theRow + 1, theCol) && !myMaze[theRow + 1][theCol].getVisited()) {
            neighbors.add(myMaze[theRow + 1][theCol]);
        }
        if (isValidRoom(theRow, theCol - 1) && !myMaze[theRow][theCol - 1].getVisited()) {
            neighbors.add(myMaze[theRow][theCol - 1]);
        }
        if (isValidRoom(theRow, theCol + 1) && !myMaze[theRow][theCol + 1].getVisited()) {
            neighbors.add(myMaze[theRow][theCol + 1]);
        }
        Collections.shuffle(neighbors); // Randomize the order of neighbors
        return neighbors;
    }

    /**
     * Checks if the given coordinates represent a valid room in the maze.
     *
     * @param theRow The x-coordinate of the room.
     * @param theCol The y-coordinate of the room.
     * @return True if the coordinates represent a valid room, false otherwise.
     */
    private boolean isValidRoom(final int theRow, final int theCol) {
        return theRow >= 0 && theRow <= myMazeSize && theCol >= 0 && theCol <= myMazeSize;
    }

    /**
     * Removes the wall between two adjacent rooms.
     *
     * @param theCurrentRoom The current room.
     * @param theNeighbor The neighboring room.
     */
    private void removeWall(final Room theCurrentRoom, final Room theNeighbor) {
        final int dRow = theNeighbor.getRow() - theCurrentRoom.getRow();
        final int dCol = theNeighbor.getCol() - theCurrentRoom.getCol();

        if (dRow == 1) {
            theCurrentRoom.setEastDoor(false);
            theNeighbor.setWestDoor(false);
        } else if (dRow == -1) {
            theCurrentRoom.setWestDoor(false);
            theNeighbor.setEastDoor(false);
        } else if (dCol == 1) {
            theCurrentRoom.setSouthDoor(false);
            theNeighbor.setNorthDoor(false);
        } else if (dCol == -1) {
            theCurrentRoom.setNorthDoor(false);
            theNeighbor.setSouthDoor(false);
        }
    }

    public void movePlayer(final Direction theDirection) {
        if (canMovePlayer(theDirection)) {
            switch (theDirection) {
                case NORTH:
                    if (myPlayerRow > 0) {
                        myPlayerRow--; // Move up
                    }
                    break;
                case SOUTH:
                    if (myPlayerRow < myMazeSize - 1) {
                        myPlayerRow++; // Move down
                    }
                    break;
                case EAST:
                    if (myPlayerCol < myMazeSize - 1) {
                        myPlayerCol++;  // Move right
                    }
                    break;
                case WEST:
                    if (myPlayerCol > 0) {
                        myPlayerCol--;  // Move left
                    }
                    break;
            }
        }
    }

    public boolean canMovePlayer(final Direction theDirection) {
        switch (theDirection) {
            case NORTH:
                if (myPlayerRow == 0) {
                    return false;
                }
                break;
            case SOUTH:
                if (myPlayerRow == myMazeSize - 1) {
                    return false;
                }
                break;
            case EAST:
                if (myPlayerCol == myMazeSize - 1) {
                    return false;
                }
                break;
            case WEST:
                if (myPlayerCol == 0) {
                    return false;
                }
                break;
        }

        Room currentRoom = getCurrentRoom();
        Door door = currentRoom.getDoor(theDirection);
        if (door.isLock() || door.isClosed()) {
            return false;
        }
        return true;
    }


    public Room getCurrentRoom() {
        if (isValidRoom(myPlayerRow, myPlayerCol)) {
            return myMaze[myPlayerRow][myPlayerCol];
        }
        return null;
    }

    public boolean isPossibleMoves() {
        for (Direction direction : Direction.values()) {
            if (canMovePlayer(direction)) {
                return true;
            }
        }
        return false;
    }

    public boolean endOfMazeCheck() {
        return myRows == myMazeSize - 1 && myCols == myMazeSize - 1;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Maze Layout:\n");
        sb.append("Player's Current Position: ").append(myRows).append(", ").append(myCols).append("\n");
        return sb.toString();
    }

    public void reset() {
        // Reset the maze dimensions
        myRows = 0;
        myCols = 0;

        // Reinitialize the maze
        initializeMaze();
        generateMaze();
    }
}