package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GameState implements Serializable {
    private Room myPlayerLocation;
    private final List<Question> myAnsweredQuestions;

    public GameState() {
        myAnsweredQuestions = new ArrayList<>();
    }

    public Room getPlayerLocation() {
        return myPlayerLocation;
    }

    public void setPlayerLocation(final Room theRoom) {
        if (theRoom == null) {
            throw new IllegalArgumentException("Player location cannot be null");
        }
        myPlayerLocation = theRoom;
    }

    public void addAnsweredQuestions(final Question theQuestion) {
        myAnsweredQuestions.add(theQuestion);
    }

    public List<Question> getAnsweredQuestions() {
        return myAnsweredQuestions;
    }

    public void updateState(final GameState theGameState) {
        myPlayerLocation = theGameState.myPlayerLocation;
        myAnsweredQuestions.clear();
        myAnsweredQuestions.addAll(theGameState.myAnsweredQuestions);
    }
}
