package Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MazeTest {

    private Maze maze;

    @BeforeEach
    public void setUp() {
        maze = new Maze(/* provide necessary arguments here */);
    }

    @Test
    public void testInitialPlayerPosition() {
        assertEquals(3, maze.getRows());
        assertEquals(3, maze.getCols());
    }

    @Test
    public void testCannotMoveWest() {
        assertTrue(maze.canMovePlayer(Direction.WEST));
    }

    @Test
    public void testEndOfMazeCheck() {
        assertFalse(maze.endOfMazeCheck());
    }

    @Test
    public void testMovePlayer() {
        if (maze.canMovePlayer(Direction.EAST)) {
            maze.movePlayer(Direction.EAST);
            assertEquals(3, maze.getRows());
            assertEquals(3, maze.getCols());
        }
    }

    @Test
    public void testCanMovePlayer() {
        assertTrue(maze.canMovePlayer(Direction.EAST));
    }

    @Test
    public void testGetCurrentRoom() {
        assertNotNull(maze.getCurrentRoom());
    }

    @Test
    public void testIsPossibleMoves() {
        assertTrue(maze.isPossibleMoves());
    }

    @Test
    public void testMovePlayerNorth() {
        // Assuming there is a room to the north
        maze.movePlayer(Direction.NORTH);
        assertEquals(2, maze.getRows());
        assertEquals(3, maze.getCols());
    }

    @Test
    public void testMovePlayerSouth() {
        // Assuming there is a room to the south
        maze.movePlayer(Direction.SOUTH);
        assertEquals(3, maze.getRows());
        assertEquals(3, maze.getCols());
    }

    @Test
    public void testMovePlayerWest() {
        maze.movePlayer(Direction.WEST);
        assertEquals(3, maze.getRows());
        assertEquals(2, maze.getCols());
    }

    @Test
    public void testMovePlayerEast() {
        // Assuming there is a room to the east
        maze.movePlayer(Direction.EAST);
        assertEquals(3, maze.getRows());
        assertEquals(3, maze.getCols());
    }

    @Test
    public void testInvalidMovePlayer() {
        // Assuming there is no room to the west
        maze.movePlayer(Direction.WEST);
        assertEquals(3, maze.getRows());
        assertEquals(2, maze.getCols());
    }

    @Test
    public void testMovePlayerMultipleTimes() {
        maze.movePlayer(Direction.EAST);
        maze.movePlayer(Direction.NORTH);
        assertEquals(2, maze.getRows());
        assertEquals(3, maze.getCols());
    }

    @Test
    public void generateMaze() {
        maze.generateMaze();
    }

    @Test
    public void testGenerateMaze() {
        maze.generateMaze();

        // Check that all rooms in the maze are not null
        for (int i = 0; i < maze.getRows(); i++) {
            for (int j = 0; j < maze.getCols(); j++) {
                assertNotNull(maze.myMaze[i][j]);
            }
        }

        // Check that the start room is correctly set
        Room startRoom = maze.myMaze[0][0];
        assertTrue(startRoom.getStart());

        // Check that the end room is correctly set
        Room endRoom = maze.myMaze[maze.getRows() - 1][maze.getCols() - 1];
        assertTrue(endRoom.getExit());
    }
}
