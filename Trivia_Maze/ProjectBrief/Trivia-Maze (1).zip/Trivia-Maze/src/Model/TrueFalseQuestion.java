package Model;

import java.io.Serializable;


public class TrueFalseQuestion extends Question implements Serializable {

    /**
     * TrueFalseQuestion constructor creates object for specified question text,
     * answer text, and question type.
     *
     * @param theQuestionText represents the text of the question.
     * @param theAnswerText represents the text of the answer.
     * @param theQuestionType represents the type of question.
     */
    public TrueFalseQuestion(final String theQuestionText, final String theAnswerText, final String theQuestionType) {
        super(theQuestionText, theAnswerText, theQuestionType);
    }

    /**
     * getCorrectAnswer gets the correct answer to true/false.
     *
     * @return correct answer, either true or false.
     */
    public boolean getCorrectAnswer() {
        return Boolean.parseBoolean(getAnswerText());

    }

    /**
     * getQuestionType gets the question type, in this case, true/false.
     *
     * @return true/false.
     */
    @Override
    public String getQuestionType() {
        return "True/False";
    }

}
