package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GameModel implements Serializable {
    private Maze myMaze;
    private Room myPlayerLocation;
    private TriviaMaze myGame;
    private SQLQuestionDataBase myQuestionFactory;
    private List<Question> myAnsweredQuestions;

    public GameModel() {
        myMaze = new Maze();
        myPlayerLocation = myMaze.getCurrentRoom();
        myAnsweredQuestions = new ArrayList<>();
        myQuestionFactory = new SQLQuestionDataBase();
    }

    public Room getPlayerLocation() {
        return myPlayerLocation;
    }

    public void setPlayerLocation(final Room thePlayerLocation) {
        if (thePlayerLocation == null) {
            throw new IllegalArgumentException("Player location cannot be null");
        }
        myPlayerLocation = thePlayerLocation;
    }

    public List<Question> getAnsweredQuestions() {
        return myAnsweredQuestions;
    }

    public void addAnsweredQuestions(final Question theQuestion) {
        myAnsweredQuestions.add(theQuestion);
    }

    public Question getQuestion() {
        // TODO: Create getNewQuestion method in SQLQuestionDataBase class that
        //  has a getNewQuestion method that fetches a new question from the database
        return null;
    }

    public void startGame() {
        myMaze.reset();
        myPlayerLocation = myMaze.getCurrentRoom();
        myAnsweredQuestions.clear();
    }

    public void endGame() {
        myMaze.reset();
        // Set the player location to the starting room of the maze
        myPlayerLocation = myMaze.getCurrentRoom();
        // Clear the list of answered questions
        myAnsweredQuestions.clear();
        // TODO: Look over start and end game methods to see if there is any other cases
        //  that need to be handled, as well as talk with the group to see if this needs
        //  to be implemented differently, and or in another class; i.e GameState or TriviaMaze.
    }

    public void updateDoorState(final Room theRoom, final Direction theDirection, final boolean theIsLocked) {
        Door door = theRoom.getDoor(theDirection);
        if (door != null) {
            if (theIsLocked) {
                door.doorLock();
            } else {
                door.doorOpen();
            }
        }
    }

    public Maze getMaze() {
        return myMaze;
    }
}
