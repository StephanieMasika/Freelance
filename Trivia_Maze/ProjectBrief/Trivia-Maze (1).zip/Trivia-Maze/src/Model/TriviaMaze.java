package Model;

import java.io.*;
import java.io.ObjectInputStream;


public class TriviaMaze {
    private final GameState myGameState;
    private final SQLQuestionDataBase myQuestionFactory;

    public TriviaMaze (final GameState theGameState, final SQLQuestionDataBase theQuestionFactory){
        myGameState = theGameState;
        myQuestionFactory = theQuestionFactory;
    }

    public void saveGameState(){
        try {
            final FileOutputStream fileOut = new FileOutputStream("gameState.ser");
            final ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(myGameState);
            out.close();
            fileOut.close();
            System.out.println("Serialized data is saved in gameState.ser");
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public void loadGameState() {
        try {
            FileInputStream fileIn = new FileInputStream("gameState.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            GameState loadedGameState = (GameState) in.readObject();
            myGameState.updateState(loadedGameState);
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("GameState class not found");
            c.printStackTrace();
        }
    }
}
