package Model;

import java.io.Serializable;
public enum Direction implements Serializable {
    NORTH(-1, 0),
    SOUTH(1, 0),
    EAST(0, 1),
    WEST(0, -1);

    private final int myRow;
    private final int myCol;

    Direction(final int theRow, final int theCol) {
        myRow = theRow;
        myCol = theCol;
    }

    public int getRow() {
        return myRow;
    }

    public int getCol() {
        return myCol;
    }
}

