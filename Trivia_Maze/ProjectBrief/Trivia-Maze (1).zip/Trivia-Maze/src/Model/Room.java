package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Room implements Serializable {
    //private final Door[] myDoor;
    private boolean myNorthDoor;
    private boolean mySouthDoor;
    private boolean myEastDoor;
    private boolean myWestDoor;
    private Door myQuestionNorth;
    private Door myQuestionSouth;
    private Door myQuestionWest;
    private Door myQuestionEast;
    private int myRow;
    private int myCol;
    private boolean myVisited;

    private static final int NORTH_DOOR = 0;
    private static final int SOUTH_DOOR = 1;
    private static final int EAST_DOOR = 2;
    private static final int WEST_DOOR = 3;
    //private static final int TOTAL_DOOR = 4;
    // field holding exit of maze
    private boolean myExit;
    //field holding start of maze
    private boolean myStart;
    private final List<Door> myDoors;

    // Creates a new Room
    public Room(final Door theNorthDoor,final Door theSouthDoor, final Door theEastDoor, final Door theWestDoor) {
        myDoors = new ArrayList<>();
        //myDoor = new Door[TOTAL_DOOR];
        myVisited = false;
        if (theNorthDoor != null) {
            //myDoor[NORTH_DOOR] = theNorthDoor;
            myDoors.add(theNorthDoor);
        }
        if (theSouthDoor != null) {
            //myDoor[SOUTH_DOOR] = theSouthDoor;
            myDoors.add(theSouthDoor);
        }
        if (theEastDoor != null) {
           // myDoor[EAST_DOOR] = theEastDoor;
            myDoors.add(theEastDoor);
        }
        if (theWestDoor != null) {
           // myDoor[WEST_DOOR] = theWestDoor;
            myDoors.add(theWestDoor);
        }
    }

//    public static int getNorthDoorIdx() {
//        return NORTH_DOOR;
//    }
//    public static int getSouthDoorIdx() {
//        return SOUTH_DOOR;
//    }
//    public static int getEastDoorIdx() {
//        return EAST_DOOR;
//    }
//    public static int getWestDoorIdx() {
//        return WEST_DOOR;
//    }
    public void setRow(final int theRow) {
        if (theRow < 0) {
            throw new IllegalArgumentException("Row value cannot be negative.");
        }
        myRow = theRow;
    }
    public int getRow() {
        return myRow;
    }
    public void setCol(final int theCol) {
        if (theCol < 0) {
            throw new IllegalArgumentException("Column value cannot be negative.");
        }
        myCol = theCol;
    }
    public int getCol() {
        return myCol;
    }
    public void setVisited(final boolean theVisited) {
        if (theVisited && myVisited) {
            throw new IllegalStateException("Room is already marked as visited");
        }
        myVisited = theVisited;
    }
    public boolean getVisited() {
        return myVisited;
    }
    public boolean getExit() {
        return myExit;
    }
    public void setExit(final boolean theExit) {
        myExit = theExit;
    }
    public void setNorthDoor(final boolean theNorthDoor) {
        myNorthDoor = theNorthDoor;
    }
    public void setSouthDoor(final boolean theSouthDoor) {
        mySouthDoor = theSouthDoor;
    }
    public void setEastDoor(final boolean theEastDoor) {
        myEastDoor = theEastDoor;
    }
    public void setWestDoor(final boolean theWestDoor) {
        myWestDoor = theWestDoor;
    }
    public boolean northDoor() {
        return myNorthDoor;
    }


    public boolean eastDoor() {
        return myEastDoor;
    }


    public boolean southDoor() {
        return mySouthDoor;
    }


    public boolean westDoor() {
        return myWestDoor;
    }
    // Getter for Door at index
    public Door getDoor(final int theDoorIdx) {
        return myDoors.get(theDoorIdx);
    }
//    public Door getDoor(final int theDoorIdx) {
//        return myDoor[theDoorIdx];
//    }
    // Getter for Door at direction
    public Door getDoor(final Direction theDir) {
        return switch (theDir) {
            case NORTH -> getDoor(NORTH_DOOR);
            case SOUTH -> getDoor(SOUTH_DOOR);
            case EAST -> getDoor(EAST_DOOR);
            case WEST -> getDoor(WEST_DOOR);
        };
    }
    public Door getQuestionNorth() {
        return myQuestionNorth;
    }

    public void setQuestionNorth(final Door theQuestionNorth) {
        myQuestionNorth = theQuestionNorth;
    }

    public Door getQuestionWest() {
        return myQuestionWest;
    }

    public void setQuestionWest(final Door theQuestionWest) {
        myQuestionWest = theQuestionWest;
    }

    public Door getQuestionSouth() {
        return myQuestionSouth;
    }

    public void setQuestionSouth(final Door theQuestionSouth) {
        myQuestionSouth = theQuestionSouth;
    }

    public Door getQuestionEast() {
        return myQuestionEast;
    }

    public void setQuestionEast(final Door theQuestionEast) {
        myQuestionEast = theQuestionEast;
    }
    // start of the maze
    public boolean getStart() {
        return myStart;
    }

    public void setStart(boolean theStart) {
        myStart = theStart;
    }
    public List<Door> getDoors() {
        return myDoors;
    }
    @Override
    public String toString() {
        StringBuilder roomString = new StringBuilder();
        roomString.append("\n\t\t\t");
        checkMovement(NORTH_DOOR, roomString);
        roomString.append("\n\n");
        checkMovement(WEST_DOOR, roomString);
        roomString.append("\t\tPlayer\t\t");
        checkMovement(EAST_DOOR, roomString);
        roomString.append("\n\n\t\t\t");
        checkMovement(SOUTH_DOOR, roomString);
        return roomString.toString();
    }
    private void checkMovement(final int theDoorIndex,
                               final StringBuilder theBuilder) {
        if (myDoors.get(theDoorIndex) == null) {
            theBuilder.append("BLOCKED");
        } else if (myDoors.get(theDoorIndex).isClosed()) {
            theBuilder.append("CLOSED DOOR");
        } else if (myDoors.get(theDoorIndex).isLock()) {
            theBuilder.append("LOCKED DOOR");
        }
        else {
            String direction = switch (theDoorIndex) {
                case NORTH_DOOR -> Direction.NORTH.toString();
                case SOUTH_DOOR -> Direction.SOUTH.toString();
                case EAST_DOOR -> Direction.EAST.toString();
                case WEST_DOOR -> Direction.WEST.toString();
                default -> "";
            };
            theBuilder.append("MOVE ");
            theBuilder.append(direction);
        }
    }
}
