package Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RoomTest {
    private Room room;
    private Door northDoor;
    private Door southDoor;
    private Door eastDoor;
    private Door westDoor;

    @BeforeEach
    public void setUp() {
        northDoor = new Door(Boolean.TRUE, Boolean.TRUE, Direction.NORTH);
        southDoor = new Door(Boolean.TRUE, Boolean.TRUE, Direction.SOUTH);
        eastDoor = new Door(Boolean.TRUE, Boolean.TRUE, Direction.EAST);
        westDoor = new Door(Boolean.TRUE, Boolean.TRUE, Direction.WEST);
        room = new Room(northDoor, southDoor, eastDoor, westDoor);
    }

    @Test
    public void testGetVisited() {
        assertFalse(room.getVisited());
    }

    @Test
    public void testSetVisited() {
        room.setVisited(true);
        assertTrue(room.getVisited());
    }

    @Test
    public void testGetExit() {
        assertFalse(room.getExit());
    }

    @Test
    public void testSetExit() {
        room.setExit(true);
        assertTrue(room.getExit());
    }

    @Test
    public void testGetQuestionNorth() {
        assertNull(room.getQuestionNorth());
        Door questionNorth = new Door(Boolean.TRUE, Boolean.TRUE, Direction.NORTH);
        room.setQuestionNorth(questionNorth);
        assertEquals(questionNorth, room.getQuestionNorth());
    }

    @Test
    public void testSetQuestionNorth() {
        assertNull(room.getQuestionNorth());
        Door questionNorth = new Door(Boolean.TRUE, Boolean.TRUE, Direction.NORTH);
        room.setQuestionNorth(questionNorth);
        assertEquals(questionNorth, room.getQuestionNorth());
    }

    @Test
    public void testGetQuestionWest() {
        assertNull(room.getQuestionWest());
        Door questionWest = new Door(Boolean.TRUE, Boolean.TRUE, Direction.WEST);
        room.setQuestionWest(questionWest);
        assertEquals(questionWest, room.getQuestionWest());
    }

    @Test
    public void testSetQuestionWest() {
        assertNull(room.getQuestionWest());
        Door questionWest = new Door(Boolean.TRUE, Boolean.TRUE, Direction.WEST);
        room.setQuestionWest(questionWest);
        assertEquals(questionWest, room.getQuestionWest());
    }

    @Test
    public void testGetQuestionSouth() {
        assertNull(room.getQuestionSouth());
        Door questionSouth = new Door(Boolean.TRUE, Boolean.TRUE, Direction.SOUTH);
        room.setQuestionSouth(questionSouth);
        assertEquals(questionSouth, room.getQuestionSouth());
    }

    @Test
    public void testSetQuestionSouth() {
        assertNull(room.getQuestionSouth());
        Door questionSouth = new Door(Boolean.TRUE, Boolean.TRUE, Direction.SOUTH);
        room.setQuestionSouth(questionSouth);
        assertEquals(questionSouth, room.getQuestionSouth());
    }

    @Test
    public void testGetQuestionEast() {
        assertNull(room.getQuestionEast());
        Door questionEast = new Door(Boolean.TRUE, Boolean.TRUE, Direction.EAST);
        room.setQuestionEast(questionEast);
        assertEquals(questionEast, room.getQuestionEast());
    }

    @Test
    public void testSetQuestionEast() {
        assertNull(room.getQuestionEast());
        Door questionEast = new Door(Boolean.TRUE, Boolean.TRUE, Direction.EAST);
        room.setQuestionEast(questionEast);
        assertEquals(questionEast, room.getQuestionEast());
    }

    @Test
    public void testSetNorthDoor() {
        assertFalse(room.northDoor());
        room.setNorthDoor(true);
        assertTrue(room.northDoor());
    }

    @Test
    public void testSetSouthDoor() {
        assertFalse(room.southDoor());
        room.setSouthDoor(true);
        assertTrue(room.southDoor());
    }

    @Test
    public void testSetEastDoor() {
        assertFalse(room.eastDoor());
        room.setEastDoor(true);
        assertTrue(room.eastDoor());
    }

    @Test
    public void testSetWestDoor() {
        assertFalse(room.westDoor());
        room.setWestDoor(true);
        assertTrue(room.westDoor());
    }
    @Test
    public void testSetAndGetRow() {
        Room room = new Room(northDoor, southDoor, eastDoor, westDoor);
        room.setRow(3);
        assertEquals(3, room.getRow());
    }
    @Test
    public void testSetAndGetCol() {
        Room room = new Room(northDoor, southDoor, eastDoor, westDoor);
        room.setCol(4);
        assertEquals(4, room.getCol());
    }
}
