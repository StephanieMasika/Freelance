package Model;

import java.util.*;

public class QuestionFactory {
    public static List<Question> getQuestionsFromDatabase(final List<String> theQuestionTypes) {
        List<Question> allQuestions = SQLQuestionDataBase.readQuestionsFromDatabase();
        List<Question> filteredQuestionsMultipleChoice = new ArrayList<>();
        List<Question> filteredQuestionsTrueFalse = new ArrayList<>();
        List<Question> filteredQuestionsShortAnswer = new ArrayList<>();

        Set<String> seenQuestionTextsMultipleChoice = new HashSet<>();
        Set<String> seenQuestionTextsTrueFalse = new HashSet<>();
        Set<String> seenQuestionTextsShortAnswer = new HashSet<>();

        for (Question question : allQuestions) {
            String questionType = question.getQuestionType();
            String questionText = question.getQuestionText();

            if (theQuestionTypes.contains(questionType)) {
                if ("Multiple-Choice".equals(questionType) && !seenQuestionTextsMultipleChoice.contains(questionText)) {
                    filteredQuestionsMultipleChoice.add(question);
                    seenQuestionTextsMultipleChoice.add(questionText);
                } else if ("True/False".equals(questionType) && !seenQuestionTextsTrueFalse.contains(questionText)) {
                    filteredQuestionsTrueFalse.add(question);
                    seenQuestionTextsTrueFalse.add(questionText);
                } else if ("Short Answer".equals(questionType) && !seenQuestionTextsShortAnswer.contains(questionText)) {
                    filteredQuestionsShortAnswer.add(question);
                    seenQuestionTextsShortAnswer.add(questionText);
                }
            }
        }
        Collections.shuffle(filteredQuestionsMultipleChoice);
        Collections.shuffle(filteredQuestionsTrueFalse);
        Collections.shuffle(filteredQuestionsShortAnswer);

        List<Question> allFilteredQuestions = new ArrayList<>();
        allFilteredQuestions.addAll(filteredQuestionsMultipleChoice);
        allFilteredQuestions.addAll(filteredQuestionsTrueFalse);
        allFilteredQuestions.addAll(filteredQuestionsShortAnswer);

        return allFilteredQuestions;
    }
}
