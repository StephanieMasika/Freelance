package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Door implements Serializable {
    private boolean myLock;
    private boolean myClosed;
    private boolean myPermanentlyLocked;
    private final List<Question> myQuestions;
    private final Direction myDirection;

    public Door (final Boolean theLock, final Boolean theClosed, final Direction theDirection) {
        myLock = theLock;
        myClosed = theClosed;
        myPermanentlyLocked = false;
        myQuestions = new ArrayList<>();
        myDirection = theDirection;
    }

    public void addQuestion(final Question theQuestion) {
        myQuestions.add(theQuestion);
    }

    public List<Question> getQuestions() {
        return myQuestions;
    }

    public boolean isLock() {
        return myLock;
    }

    public void setLock(final boolean theLock) {
        myLock = theLock;
    }

    public boolean isClosed() {
        return myClosed;
    }

    public void setClosed(final boolean theClosed){
        myClosed = theClosed;
    }

    public void doorLock(){
        myLock = true;
    }

    public void doorOpen(){
        myLock = false;
        myClosed = false;
    }

    public boolean permanentlyLocked() {
        return myPermanentlyLocked;
    }

    public void setPermanentlyLocked(final boolean thePermanentlyLocked) {
        myPermanentlyLocked = thePermanentlyLocked;
    }

    public Direction getDirection() {
        return myDirection;
    }
    public void reset() {
        myLock = false;
        myClosed = true;
    }
}
