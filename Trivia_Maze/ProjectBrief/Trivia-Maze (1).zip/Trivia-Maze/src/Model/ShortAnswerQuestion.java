package Model;

import java.io.Serializable;


public class ShortAnswerQuestion extends Question implements Serializable {
    /**
     * Represents the max length allowed for a short answer question.
     */
    private final int myMaxAnswerLength;

    /**
     * ShortAnswerQuestion constructor creates object for specified question text,
     * answer text, and question type. The max answer length is set to two words.
     *
     * @param theQuestionText represents the text of the question.
     * @param theAnswerText represents the text of the answer.
     * @param theQuestionType represents the type of question.
     */
    public ShortAnswerQuestion(final String theQuestionText, final String theAnswerText, final String theQuestionType) {
        super(theQuestionText, theAnswerText, theQuestionType);
        this.myMaxAnswerLength = 2;
    }

    /**
     * getMaxAnswerLength gets the max length for answer.
     *
     * @return max length for answer.
     */
    public int getMaxAnswerLength() {
        return myMaxAnswerLength;
    }

    /**
     * getQuestionType gets the question type, in this case, short answer.
     *
     * @return short answer.
     */
    @Override
    public String getQuestionType() {
        return "Short Answer";
    }


}